// 输入名字
let prce = +rompt('输入商品的价格:')
let num = +prompt('输入商品的数量:')
let address = prompt('输入商品的收获地址:')
// 计算总额
let todal = prce * num
// 页面打印
document.write(`
<table>
        <tr>
            <th商品名称</th>
            <th>商品价格</th>
            <th>商品数量</th>
            <th>总价</th>
            <th>收货地址</th>
        </tr>
        <tr>
            <td>小米</td>
            <td>${prce}</td>
            <td>${num}</td>
            <td>${todal}</td>
            <td>${address}</td>
        </tr>
        </table>
`)