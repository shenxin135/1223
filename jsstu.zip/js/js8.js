// 定义数
let num = +prompt('请输入第一个：')
let num2 = +prompt('请输入第二个：')
// 转换成数字
 alert(num + num2)