// typeof检测数据类型
let num = 10
console.log(typeof num)
let str ='pring'
console.log(typeof str)
let str1 = '10'
console.log(typeof str1)


// +隐式转换，把字符串转换成数字
console.log(+'222')

// 显示转换
let str2 = '123'
console.log(Number(str2))


console.log(parseInt('12px'));//输出值为12
console.log(parseFloat('123.434px'))//输出为123.434