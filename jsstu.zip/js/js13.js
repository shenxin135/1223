// 用户输入
let score = +prompt('请输入成绩')
// 进行判断输出

if (score >= 700) {
    alert('gongx')

    
}
console.log('-----------------')