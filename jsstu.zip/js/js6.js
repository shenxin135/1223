let num 
console.log(num)