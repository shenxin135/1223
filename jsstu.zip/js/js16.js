// 用户输入
let score = +prompt('请输入成绩：')
// 判断输入
if (score >= 90) {
    alert('成绩优秀')
}else if (score >= 70) {
    alert('成绩良好')
}else if (score >= 60) {
    alert('成绩及格')
}else {
    alert('成绩不及格')
}