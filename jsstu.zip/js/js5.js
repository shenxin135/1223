let age = prompt('请输入年龄')
let uname = prompt('请输入名字')
document.write(`大家好，我叫${uname}，今年${age}`)