// 用户输入
let num = +print('请输入一个数字')
document.write(num % 4 === 0 && num % 100 !== 0)

// 弹出结果


