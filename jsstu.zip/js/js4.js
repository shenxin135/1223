// 页面弹出输入框
let r = prompt('请输入')
// 计算面积
let re = 3.14 * r * r
// 页面弹输出
console.log(re)



// 模板字符串
let age = 20
document.write(`我今年${age}岁`)