// 逻辑与 一假则假
console.log(true && true)
console.log( false && true)
console.log(3 < 5 && 3 > 2)
console.log(3 < 5 && 3 < 2)
console.log('________________________')
//  逻辑或 一真则真
console.log(true || true)
console.log(false || true)
console.log(false || false)
console.log('_________________')
// 罗技非 取反
console.log(!true)
console.log('___________________')
