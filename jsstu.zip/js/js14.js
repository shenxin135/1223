// 用户输入
let uname = prompt('请输入用户名')
let pwd = prompt('请输入密码:')

// 判断输出
if (uname === 'sx' && pwd === '123456') {
    alert('恭喜')
}else{
    alert('用户名或者密码错误')
}